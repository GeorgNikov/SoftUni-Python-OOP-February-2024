from project.trip import Trip
from unittest import TestCase, main


class Test(TestCase):

    def setUp(self):
        self.trip = Trip(10000, 1, False)
        self.trip_family = Trip(10000, 2, True)

    def test_correct_init(self):
        self.assertEqual(10000, self.trip.budget)
        self.assertEqual(1, self.trip.travelers)
        self.assertEqual(2, self.trip_family.travelers)
        self.assertFalse(self.trip.is_family)
        self.assertTrue(self.trip_family.is_family)
        self.assertDictEqual({}, self.trip.booked_destinations_paid_amounts)

    def test_travelers__setter_wrong_value_raise_value_error(self):
        with self.assertRaises(ValueError) as ve:
            self.trip.travelers = 0

        self.assertEqual('At least one traveler is required!', str(ve.exception))

    def test_is_family__setter_invalid_return_false(self):
        self.trip.travelers = 1
        self.assertFalse(self.trip.is_family)

        self.trip_family.travelers = 4
        self.assertTrue(self.trip_family.is_family)

    def test_book_a_trip__if_destination_not_exist_return_string(self):
        result = self.trip.book_a_trip('Ireland')

        self.assertEqual('This destination is not in our offers, please choose a new one!', result)

    def test_book_a_trip__if_destination_exist_but_budget_is_not_enough_return_string(self):
        self.trip.budget = 100
        result = self.trip.book_a_trip('Bulgaria')

        self.assertEqual('Your budget is not enough!', result)

    def test_book_a_trip__if_destination_exist_budget_is_enough_return_string(self):
        result = self.trip.book_a_trip('Bulgaria')

        self.assertDictEqual({'Bulgaria': 500}, self.trip.booked_destinations_paid_amounts)
        self.assertEqual(9500, self.trip.budget)
        self.assertEqual(f'Successfully booked destination Bulgaria! Your budget left is 9500.00', result)

    def test_booking_status__if_no_booking_return_string(self):
        result = self.trip.booking_status()

        self.assertEqual(f'No bookings yet. Budget: {self.trip.budget:.2f}', result)

    def test_booking_status__if_booking_one_person_return_sorted_string(self):
        self.trip.book_a_trip('Bulgaria')

        expect_string = ("Booked Destination: Bulgaria\nPaid Amount: 500.00\n"
                         "Number of Travelers: 1\nBudget Left: 9500.00")

        self.assertEqual(expect_string, self.trip.booking_status())

    def test_booking_status__if_booking_two_person_return_sorted_string(self):
        self.trip.travelers = 2
        self.trip.book_a_trip('Bulgaria')

        expect_string = ("Booked Destination: Bulgaria\nPaid Amount: 1000.00\n"
                         "Number of Travelers: 2\nBudget Left: 9000.00")

        self.assertEqual(expect_string, self.trip.booking_status())


if __name__ == '__main__':
    main()
